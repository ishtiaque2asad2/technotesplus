import axios from "axios";
import BASE_URL from './base_url'
import AuthHeader from './auth_header'
class Note{
    static GetMyNotes(){
        return axios.get(BASE_URL+"/note/api/v1/",AuthHeader()).then(response=>{
            return Promise.resolve(response.data);
        },error=>{
           return Promise.reject(error.data);
        });
    }
    static GetSharedByMeNotes(){
        return axios.get(BASE_URL+"/note/sharedbyme/api/v1/",AuthHeader()).then(response=>{
            return Promise.resolve(response.data);
        },error=>{
            return Promise.reject(error.data);
        });
    }
    static GetSharedWithMeNotes(){
        return axios.get(BASE_URL+"/note/sharedwithme/api/v1/",AuthHeader()).then(response=>{
            return Promise.resolve(response.data);
        },error=>{
            return Promise.reject(error.data);
        });
    }
    static saveMyNote(data){
        return axios.post(BASE_URL+"/note/api/v1/",data,AuthHeader()).then(response=>{
            return Promise.resolve(response.data);
        },error=>{
            return Promise.reject(error.data);
        });
    }
    static updateMyNote(data){
        return axios.patch(BASE_URL+"/note/api/v1/"+data['unique_id']+"/",data,AuthHeader()).then(response=>{
            return Promise.resolve(response.data);
        },error=>{
            return Promise.reject(error.data);
        });
    }
    static getMyNote(unique_id){
        return axios.get(BASE_URL+"/note/api/v1/"+unique_id+"/",AuthHeader()).then(response=>{
            return Promise.resolve(response.data);
        },error=>{
            return Promise.reject(error.data);
        });
    }
}
export default Note