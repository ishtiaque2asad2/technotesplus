import axios from "axios";
import BASE_URL from './base_url'
import AuthHeader from './auth_header'
class Auth{
    static login(data){
        return axios.post(BASE_URL+"/authentication/api/v1/token/",data).then(response=>{
            return Promise.resolve(response.data);

        },error=>{
            return Promise.reject(error.response.data);
        });
    }
    static updateProfile(data){
        let username = localStorage.getItem('username');
        return axios.patch(BASE_URL+"/user/api/v1/"+username+"/",data,AuthHeader()).then(response=>{
            return Promise.resolve(response.data);
        },error=>{
            return Promise.reject(error.response.data);
        });
    }
    static changePassword(data){
        return axios.patch(BASE_URL+"/user/api/v1/changepassword/",data,AuthHeader()).then(response=>{
            return Promise.resolve(response.data);
        },error=>{
            return Promise.reject(error.response.data);
        });
    }
    static logout(){
        localStorage.clear();

    }
}

export default Auth