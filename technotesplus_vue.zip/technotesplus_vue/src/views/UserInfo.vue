<template>
  <div class="text-center" style="padding-top: 200px">
    <form class="form-signin" @submit.prevent="submit">

      <h1 class="h3 mb-3 font-weight-normal">Profile</h1>
      <label for="inputFirstName" class="sr-only">First Name</label>
      <input v-model="first_name" type="text" id="inputFirstName" class="form-control" placeholder="First Name" required autofocus>
      <label for="inputLastName" class="sr-only">Last Name</label>
      <input v-model="last_name" type="text" id="inputLastName" class="form-control" placeholder="Last Name" required>
      <label for="inputEmail" class="sr-only">Email</label>
      <input v-model="email" type="text" id="inputEmail" class="form-control" placeholder="Email" required>
      <br/>
      <button class="btn btn-lg btn-primary btn-block" type="submit">Change</button>

    </form>
  </div>
</template>

<script>
// @ is an alias to /src

import Auth from "@/services/auth";

export default {
  name: 'Userinfo',
  data: function() {
    return {
      first_name:"",
      last_name:"",
      email:""
    }
  },
  methods:{
    submit(){
        let data = {
          first_name: this.first_name,
          last_name: this.last_name,
          email: this.email
        }
        Auth.updateProfile(data).then((response)=>{
          this.$toasted.show('Data Updated Successfully',{
            position:'top-center',
            duration:2000,
            type: "success"
          });
          localStorage.setItem("first_name",response['first_name'])
          localStorage.setItem("last_name",response['last_name'])
          localStorage.setItem("email",response['email'])

        },error => {
          console.log(error);
          this.$toasted.show(error[0],{
            position:'top-center',
            duration:2000,
            type: "error"
          });
        });
    }
  },
  mounted() {
    this.first_name = localStorage.getItem("first_name")
    this.last_name = localStorage.getItem("last_name")
    this.email = localStorage.getItem("email")
  }
}
</script>
<style scoped>
html,
body {
  height: 100%;
}

body {
  display: -ms-flexbox;
  display: -webkit-box;
  display: flex;
  -ms-flex-align: center;
  -ms-flex-pack: center;
  -webkit-box-align: center;
  align-items: center;
  -webkit-box-pack: center;
  justify-content: center;
  padding-top: 40px;
  padding-bottom: 40px;
  background-color: #f5f5f5;
}

.form-signin {
  width: 100%;
  max-width: 330px;
  padding: 15px;
  margin: 0 auto;
}
.form-signin .checkbox {
  font-weight: 400;
}
.form-signin .form-control {
  position: relative;
  box-sizing: border-box;
  height: auto;
  padding: 10px;
  font-size: 16px;
}
.form-signin .form-control:focus {
  z-index: 2;
}
.form-signin input[type="email"] {
  margin-bottom: -1px;
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;
}
.form-signin input[type="password"] {
  margin-bottom: 10px;
  border-top-left-radius: 0;
  border-top-right-radius: 0;
}
</style>
