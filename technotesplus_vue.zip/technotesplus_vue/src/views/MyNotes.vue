<template>
  <main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
    <h2>My Notes</h2>

    <div class="table-responsive">
      <table class="table table-striped table-sm">
        <thead>
        <tr>
          <th>#</th>
          <th>Title</th>
          <th>Tags</th>

        </tr>
        </thead>
        <tbody>
        <tr v-for="(data,index) in myNotes" :key="index">
          <td>{{ index + 1 }}</td>
          <td><router-link :to="getLink(data)">{{ data.title }}</router-link> </td>
          <td>{{ data.tag_string }}</td>

        </tr>
        </tbody>
      </table>
    </div>
  </main>
</template>

<script>
import Note from "@/services/note";

export default {
  name: "MyNotes",
  data:function (){
    return{
      myNotes: []
    }
  },
  methods:{
    getLink(data){
      return '/detailnote/'+data.unique_id;
    },
    getMyNotes(){
      Note.GetMyNotes().then(response=>{
        this.myNotes = response;
      })
    }
  },
  mounted() {
    this.getMyNotes();
  }
}
</script>

<style scoped>

</style>