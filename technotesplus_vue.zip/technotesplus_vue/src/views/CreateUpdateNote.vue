<template>
  <div class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4" >
    <form class="form-signin" @submit.prevent="submit">

        <div class="col-md-6 form-group">
          <label for="inputTitle" style="text-align: left">Title</label>
          <input v-model="title" type="text" id="inputTitle" class="form-control" placeholder="Title of note" required autofocus>
        </div>

      <br/>

        <vue-editor v-model="html" :editorOptions="editorOptions"></vue-editor>

        <button class="btn btn-lg btn-primary btn-block" type="submit">Submit</button>

    </form>

  </div>
</template>

<script>
import { VueEditor, Quill } from "vue2-editor";
import Emoji from "quill-emoji";
import "quill-emoji/dist/quill-emoji.css";
import Note from "@/services/note";

Quill.register(
    {
      "formats/emoji": Emoji.EmojiBlot,
      "modules/short_name_emoji": Emoji.ShortNameEmoji,
      "modules/toolbar_emoji": Emoji.ToolbarEmoji,
      "modules/textarea_emoji": Emoji.TextAreaEmoji
    },
    true
);

const editorOptions = {
  modules: {
    toolbar: {
      container: [
        [{ size: ["small", false, "large"] }],
        ["bold", "italic", "underline", "strike"],
        ["blockquote", "code-block"],
        [{ list: "ordered" }, { list: "bullet" }],
        [{ script: "sub" }, { script: "super" }],
        [{ indent: "-1" }, { indent: "+1" }],
        [{ direction: "rtl" }],
        [{ header: [1, 2, 3, 4, 5, 6, false] }],
        [{ color: [] }, { background: [] }],
        [{ font: [] }],
        [{ align: [] }],
        ["clean"],
        // ["link", "image", "video"],
        ["emoji"]
      ],
      handlers: {
        emoji: function() {}
      }
    },
    short_name_emoji: true,
    toolbar_emoji: true,
    textarea_emoji: true
  }
};

export default {
  components: {
    VueEditor,
  },
  data: () => ({
    html: "Initial Content",
    title:"",
    create:true,
    unique_id:""
  }),
  computed: { editorOptions: () => editorOptions },
  methods:{
    submit(){
      let data = {"note":this.html,title:this.title,tags:[]}
      if(this.create){
        Note.saveMyNote(data).then(()=>{
          this.$toasted.show("Note created successfully",{
            position:'top-center',
            duration:2000,
            type: "success"
          });
          this.$router.push('/');
        },error=>{
          console.log(error);
        })
      }
      else {
        let data = {"note":this.html,title:this.title,unique_id:this.unique_id}
        Note.updateMyNote(data).then(()=>{
          this.$toasted.show("Note updated successfully",{
            position:'top-center',
            duration:2000,
            type: "success"
          });
        },error=>{
          console.log(error);
        })
      }

    }
  },
  mounted() {
    let unique_id = this.$route.params.unique_id
    if(unique_id){
      this.create=false;
      this.unique_id=unique_id;
      Note.getMyNote(unique_id).then(response=>{
        this.title=response.title;
        this.html=response.note;
        console.log(response.note);
      },error=>{
        console.log(error);
      })
    }
  }
};
</script>

<style scoped>

</style>