<template>
  <div class="text-center" style="padding-top: 200px">
    <form class="form-signin" @submit.prevent="submit">

      <h1 class="h3 mb-3 font-weight-normal">Change Password</h1>
      <label for="inputPreviousPassword" class="sr-only">Previous Password</label>
      <input v-model="old_password" type="password" id="inputPreviousPassword" class="form-control" placeholder="Type your Previous Password" required autofocus>
      <label for="inputPassword" class="sr-only">Password</label>
      <input v-model="password" type="password" id="inputPassword" class="form-control" placeholder="Type your Password" required autofocus>
      <label for="inputRepassword" class="sr-only">Password</label>
      <input v-model="repassword" type="password" id="inputRepassword" class="form-control" placeholder="Retype your Password" required>
      <br/>
      <button class="btn btn-lg btn-primary btn-block" type="submit">Change</button>

    </form>
  </div>
</template>

<script>
// @ is an alias to /src

import Auth from "@/services/auth";

export default {
  name: 'ChangePassword',
  data: function() {
    return {
      repassword:"",
      password:"",
      old_password:""
    }
  },
  methods:{
    submit(){
      if(this.password===this.repassword){
        Auth.updateProfile({old_password:this.old_password,new_password:this.password}).then(()=>{
          this.$toasted.show('Password Changed Successfully',{
            position:'top-center',
            duration:2000,
            type: "success"
          });
          this.$router.push("/");
        },error => {
          console.log(error);
          this.$toasted.show(error[0],{
            position:'top-center',
            duration:2000,
            type: "error"
          });
        });
      }
      else {
        this.$toasted.show("Password mismatch",{
          position:'top-center',
          duration:2000,
          type: "error"
        });
      }

    }
  }
}
</script>
<style scoped>
html,
body {
  height: 100%;
}

body {
  display: -ms-flexbox;
  display: -webkit-box;
  display: flex;
  -ms-flex-align: center;
  -ms-flex-pack: center;
  -webkit-box-align: center;
  align-items: center;
  -webkit-box-pack: center;
  justify-content: center;
  padding-top: 40px;
  padding-bottom: 40px;
  background-color: #f5f5f5;
}

.form-signin {
  width: 100%;
  max-width: 330px;
  padding: 15px;
  margin: 0 auto;
}
.form-signin .checkbox {
  font-weight: 400;
}
.form-signin .form-control {
  position: relative;
  box-sizing: border-box;
  height: auto;
  padding: 10px;
  font-size: 16px;
}
.form-signin .form-control:focus {
  z-index: 2;
}
.form-signin input[type="email"] {
  margin-bottom: -1px;
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;
}
.form-signin input[type="password"] {
  margin-bottom: 10px;
  border-top-left-radius: 0;
  border-top-right-radius: 0;
}
</style>
