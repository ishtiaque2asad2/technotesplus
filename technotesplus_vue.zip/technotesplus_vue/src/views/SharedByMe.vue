<template>
  <main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
    <h2>Notes Shared By me</h2>
    <div class="table-responsive">
      <table class="table table-striped table-sm">
        <thead>
        <tr>
          <th>#</th>
          <th>Title</th>
          <th>Shared With</th>
          <th>Viewed</th>
        </tr>
        </thead>
        <tbody>
        <tr v-for="(data,index) in mySharedNotes" :key="index">
          <td>{{ index + 1 }}</td>
          <td>{{ data.note_title }}</td>
          <td>{{ data.shared_with_name }}</td>
          <td v-if="data.is_read">Yes</td>
          <td else>No</td>

        </tr>
        </tbody>
      </table>
    </div>
  </main>
</template>

<script>
import Note from "@/services/note";

export default {
  name: "SharedByMe",
  data:function (){
    return{
      mySharedNotes: []
    }
  },
  methods:{
    getMySharedNotes(){
      Note.GetSharedByMeNotes().then(response=>{
        this.mySharedNotes = response;
        console.log(response);
      })
    }
  },
  mounted() {
    this.getMySharedNotes();
  }
}
</script>

<style scoped>

</style>