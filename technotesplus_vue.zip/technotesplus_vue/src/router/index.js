import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import Login from '../views/Login'
import MyNotes from "@/views/MyNotes";
import SharedByMe from "@/views/SharedByMe";
import SharedWithMe from "@/views/SharedWithMe";
import ChangePassword from "@/views/ChangePassword";
import UserInfo from "@/views/UserInfo";
import CreateUpdateNote from "@/views/CreateUpdateNote";

Vue.use(VueRouter)

const routes = [
  {
    path: '/login',
    name: 'Login',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: Login
  },
  {
    path: '/',
    name: 'Home',
    component: Home,
    children:[
      {
        // UserProfile will be rendered inside User's <router-view>
        // when /user/:id/profile is matched
        path: '',
        name:'MyNotes',
        components:{
          default:MyNotes
        },

      },
      {
        // UserProfile will be rendered inside User's <router-view>
        // when /user/:id/profile is matched
        path: '/sharedbyme',
        name:'SharedByMe',
        components:{
          default:SharedByMe
        },

      },
      {
        // UserProfile will be rendered inside User's <router-view>
        // when /user/:id/profile is matched
        path: '/sharedwithme',
        name:'SharedWithMe',
        components:{
          default:SharedWithMe
        },

      },
      {
        // UserProfile will be rendered inside User's <router-view>
        // when /user/:id/profile is matched
        path: '/createnote',
        name:'CreateUpdateNote',
        components:{
          default:CreateUpdateNote
        }

      },
      {
        // UserProfile will be rendered inside User's <router-view>
        // when /user/:id/profile is matched
        path: '/detailnote/:unique_id',
        name:'DetailNote',
        components:{
          default:CreateUpdateNote
        }

      },
      {
        // UserProfile will be rendered inside User's <router-view>
        // when /user/:id/profile is matched
        path: '/changepassword',
        name:'ChangePassword',
        components:{
          default:ChangePassword
        }

      },
      {
        // UserProfile will be rendered inside User's <router-view>
        // when /user/:id/profile is matched
        path: '/profile',
        name:'Profile',
        components:{
          default:UserInfo
        }

      }
    ]
  },
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
